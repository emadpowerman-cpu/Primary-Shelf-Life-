// ==========================================
// DUNKIN' PRIMARY SHELF LIFE - APPLICATION LOGIC
// ==========================================

const { createApp, ref, computed, onMounted, nextTick, watch } = Vue;

const STORAGE_KEY = 'dunkin_primary_shelf_life_v1';

// All 120 Dunkin' Items
const DUNKIN_PRODUCTS = [
  // Syrups & Sauces
  { id: "p_1", name: "BLUE BAY SYRUP (6 X1 LTR) PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف (درجة حرارة الغرفة)", shelfLifeMonths: 18 },
  { id: "p_2", name: "CARAMEL SAUCE PEN 300 ML PCS", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "300 ML", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_3", name: "DA VINCI MANGO FRUIT MIX (6X1 LTR) PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_4", name: "MANGO DRAGON FRUIT PUREE (6 X1 LTR) PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "مبرد 1-4°C", shelfLifeMonths: 9 },
  { id: "p_5", name: "PINEAPPLE FRUIT MIX (1LX6PCS) CTN 6 PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_6", name: "RM.TOPPING.NUTELLA 3KG PKT 3 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "3 KG", storage: "جاف 18-20°C", shelfLifeMonths: 12 },
  { id: "p_7", name: "SAFFRON SAUCE (4 X 1.89 LTR) PCS 1.89 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1.89 LTR", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_8", name: "SAUCE.ARABESCHI CARAMEL FLEUR DE SEL 3 KG FOR FRAPPE PKT 3 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "3 KG", storage: "جاف", shelfLifeMonths: 18 },
  { id: "p_9", name: "SAUCE.ARABESCHI STRAWBERRY EXTRA 1 KG PKT 1 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 KG", storage: "جاف / مبرد", shelfLifeMonths: 12 },
  { id: "p_10", name: "SAUCE.BLUE OCEAN 750ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_11", name: "SAUCE.CHOCOLATE FLAVORED SAUCE (2 LTR) PCS 2 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "2 LTR", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_12", name: "SAUCE.DA VINCI SALTED CARAMEL SAUCE 2LTR FOR LATTE PCS 2 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "2 LTR", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_13", name: "SAUCE.DAVINCI GOURMET ARABIC COFFEE FLAVORED SAUCE (3PX2L) PCS 2 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "2 LTR", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_14", name: "SAUCE.LEMONADE 1 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف / مبرد", shelfLifeMonths: 12 },
  { id: "p_15", name: "SAUCE.MATCHA (3 X 2LTR) PCS 2 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "2 LTR", storage: "مبرد 1-4°C", shelfLifeMonths: 9 },
  { id: "p_16", name: "SAUCE.PINOPIGUINO PISTACHIO 3 KG PKT 3 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "3 KG", storage: "جاف", shelfLifeMonths: 18 },
  { id: "p_17", name: "SAUCE.PISTACHIO 1 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_18", name: "SAUCE.WATERMELON 750ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_19", name: "SAUCE.WHITE CHOCOLATE SAUCE 2 LTR PCS 2 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "2 LTR", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_20", name: "SPREADS.CHOCO HAZELNUT SPREAD 400 GM PKT 0.400 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "400 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_21", name: "SPREADS.HONEY 380 GM PCS 0.380 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "380 GM", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_22", name: "SPREADS.PESTO SAUCE 185 GM PCS 0.185 KG", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "185 GM", storage: "مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_23", name: "WATERMELON SYRUP 750ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_24", name: "SYRUP.BLUEBERRY PUREE 01 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_25", name: "SYRUP.CARAMEL SAUCE PEN 165 ML PCS 0.165 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "165 ML", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_26", name: "SYRUP.CARAMEL SYRUP 750 ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_27", name: "SYRUP.CHERRY PUREE 01 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_28", name: "SYRUP.DAVINCI STRAWBERRY SYRUP (12 X 750ML) PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_29", name: "SYRUP.HAZELNUT SYRUP 750 ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_30", name: "SYRUP.MOCHA SAUCE PEN 165 ML PCS 0.165 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "165 ML", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_31", name: "SYRUP.MONIN BLUEBERRY SYRUP (6X1LTR) PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_32", name: "SYRUP.MONIN PEACH ICETEA SYRUP 01 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_33", name: "SYRUP.MONIN RANCHO LEMONADE SYRUP 01 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_34", name: "SYRUP.MONIN STRAWBERRY SYRUP 01 LTR PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_35", name: "SYRUP.SPICE BROWN SUGAR SYRUP PCS 1 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_36", name: "SYRUP.SUGAR CANE SYRUP 750 ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_37", name: "SYRUP.VANILLA SYRUP 750 ML PCS 0.750 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "750 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_38", name: "SAUCE.MAYONNAISE CREAMY 400ML PCS 0.400 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "400 ML", storage: "مبرد بعد الفتح", shelfLifeMonths: 9 },
  { id: "p_39", name: "SAUCE.TOMATO KETCHUP 570ML PCS 0.570 LTR", category: "syrups", categoryTitle: "صوصات وسيروب", unit: "570 ML", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },

  // Coffee & Beans
  { id: "p_40", name: "COFFEE.BOLD ROAST ESPRESSO (10CAPS) PKT 1 PCS", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "10 CAPS", storage: "جاف وبارد", shelfLifeMonths: 18 },
  { id: "p_41", name: "COFFEE.DD COFFEE BEANS BAG 5 LBS CTN 6 PKT 2.27 KG", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "2.27 KG", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_42", name: "COFFEE.DD COFFEE GROUNDS BAG 01 LBS PCS", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "1 LBS", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_43", name: "COFFEE.DD DARK ROAST GROUNDS BAG 01 LBS PKT 0.453 KG", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "0.453 KG", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_44", name: "COFFEE.DD DARK ROAST WHOLE BEAN BAG 02 LBS CTN 8 PKT 0.909 KG", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "0.909 KG", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_45", name: "COFFEE.DD DECAF COFFEE GROUNDS BAG 01 LBS PKT 0.453 KG", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "0.453 KG", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_46", name: "COFFEE.ESPRESSO BEANS BAG 01 KG CTN 6 PKT 1 KG", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "1 KG", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_47", name: "COFFEE.LIGHT ROAST ESPRESSO (10CAPS) CTN 10 PKT 1 PC", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "10 CAPS", storage: "جاف وبارد", shelfLifeMonths: 18 },
  { id: "p_48", name: "COFFEE.SIGNATURE BLEND ESPRESSO (10CAPS) CTN 10 PKT 1 PC", category: "coffee", categoryTitle: "قهوة وكبسولات", unit: "10 CAPS", storage: "جاف وبارد", shelfLifeMonths: 18 },
  { id: "p_49", name: "TEA.BOLDBREAKFAST BLACK TEA (1X15 /BOX) PKT 15 PCS", category: "coffee", categoryTitle: "قهوة وشاي", unit: "15 PCS", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_50", name: "TEA.KARAK CHAI 500GM PKT 0.500 KG", category: "coffee", categoryTitle: "قهوة وشاي", unit: "500 GM", storage: "جاف", shelfLifeMonths: 18 },

  // Dairy & Milks
  { id: "p_51", name: "MILK ALMOND DRINK ORIGINAL 8X1LTR CTN 8 PCS 1 LTR", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1 LTR", storage: "جاف قبل الفتح / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_52", name: "MILK COCONUT DRINK ORIGINAL 12X1LTR CTN 12 PCS 1 LTR", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1 LTR", storage: "جاف قبل الفتح / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_53", name: "MILK OAT DRINK ORIGINAL 6X1LTR CTN 6 PCS 1 LTR", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1 LTR", storage: "جاف قبل الفتح / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_54", name: "MILK.FULL FAT MILK 01 LTR CTN 12 PCS 1 LTR", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1 LTR", storage: "جاف UHT / مبرد 4°C بعد الفتح", shelfLifeMonths: 9 },
  { id: "p_55", name: "MILK.LOW FAT MILK 01 LTR CTN 12 PCS 1 LTR", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1 LTR", storage: "جاف UHT / مبرد 4°C بعد الفتح", shelfLifeMonths: 9 },
  { id: "p_56", name: "MILK.SOYA DRINK ORIGINAL 1LTR CTN 12 PCS", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1 LTR", storage: "جاف قبل الفتح / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_57", name: "CHEESE.SLICE CHEESE FOR SANDWICH (10 SLICES) PKT 10 PCS", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "10 SLICES", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_58", name: "CREAM CHEESE (12PCSx 300GM) CTN 12 PKT 0.3 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "300 GM", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_59", name: "CREAM CHEESE (2KG) CTN 8 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "2 KG", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_60", name: "CREAM CHEESE (32PCS x280 GM) PKT 0.280 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "280 GM", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_61", name: "CREAM CHEESE (4PCS x 1.65KG) PKT 1.65 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1.65 KG", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_62", name: "CREAM CHEESE (6PCS x 1.15KG) PKT 1.15 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "1.15 KG", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_63", name: "CREAM CHEESE (8PCS x 0.50KG) PKT 0.5 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "0.5 KG", storage: "مبرد 1-4°C", shelfLifeMonths: 6 },
  { id: "p_64", name: "HONEY GRANULA YOGHURT 1X36X170G PCS", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "170 GM", storage: "مبرد 1-4°C", shelfLifeMonths: 1 },
  { id: "p_65", name: "RASBERRY GRANULA YOGHURT 1X36X170G PCS", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "170 GM", storage: "مبرد 1-4°C", shelfLifeMonths: 1 },
  { id: "p_66", name: "SPREADS.LABNEH FULL FAT (180 GMS 60 PCS) PKT 0.18 KG", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "180 GM", storage: "مبرد 1-4°C", shelfLifeMonths: 3 },
  { id: "p_67", name: "TOPPING.WHIPPING CREAM SPRAY 250 ML PCS 0.250 LTR", category: "dairy", categoryTitle: "ألبان وحليب وبدائل", unit: "250 ML", storage: "مبرد 1-4°C", shelfLifeMonths: 9 },

  // Bakery & Sandwiches
  { id: "p_68", name: "SANDWICH.LIQUID WHOLE EGG CHILLED PAST 1KG KG", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "1 KG", storage: "مبرد 1-4°C", shelfLifeMonths: 1 },
  { id: "p_69", name: "MORTADELLA.CHICKEN MORTADELLA PKT 5 PCS", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "5 PCS", storage: "مبرد 1-4°C", shelfLifeMonths: 3 },
  { id: "p_70", name: "SANDWHICH FROZEN EGG 1KG KG", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "1 KG", storage: "مجمد -18°C", shelfLifeMonths: 12 },
  { id: "p_71", name: "SANDWICH.DD BAGEL CINNAMON (1X60 PCS) CTN 60 PCS", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "60 PCS", storage: "مجمد -18°C", shelfLifeMonths: 9 },
  { id: "p_72", name: "SANDWICH.DD BAGEL MULTIGRAIN (1X60 PCS) CTN 60 PCS", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "60 PCS", storage: "مجمد -18°C", shelfLifeMonths: 9 },
  { id: "p_73", name: "SANDWICH.DD BAGEL PLAIN (1X60 PCS) CTN 60 PCS", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "60 PCS", storage: "مجمد -18°C", shelfLifeMonths: 9 },
  { id: "p_74", name: "SANDWICH.DD TOAST TEXAS (1X100 PCS) CTN 100 PCS", category: "bakery", categoryTitle: "مخبوزات وساندوتشات", unit: "100 PCS", storage: "مجمد -18°C", shelfLifeMonths: 9 },

  // Beverages & Juices
  { id: "p_75", name: "CHERRY JUICE 300ML CTN 24 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "300 ML", storage: "جاف / مبرد قبل التقديم", shelfLifeMonths: 12 },
  { id: "p_76", name: "MANGO JUICE 300ML CTN 24 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "300 ML", storage: "جاف / مبرد قبل التقديم", shelfLifeMonths: 12 },
  { id: "p_77", name: "ORANGE JUICE 300 ML CTN 24 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "300 ML", storage: "جاف / مبرد قبل التقديم", shelfLifeMonths: 12 },
  { id: "p_78", name: "EVIAN SPARKLING WATER CAN 24 X 0.33L CTN 24 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "0.33 L", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_79", name: "KINZA-SPARKLING WATER BOTTLE 250ML CTN 24 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "250 ML", storage: "جاف", shelfLifeMonths: 18 },
  { id: "p_80", name: "SPARKLING SODA 24X300ML CTN 24 PCS 0.300 LTR", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "300 ML", storage: "جاف", shelfLifeMonths: 18 },
  { id: "p_81", name: "SPARKLING SODA 30X250ML CTN 30 PCS 0.250 LTR", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "250 ML", storage: "جاف", shelfLifeMonths: 18 },
  { id: "p_82", name: "WATER.EVIAN WATER BOTTLE 500 ML CTN 24 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "500 ML", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_83", name: "WATER.NOVA WATER BOTTLE 330 ML CTN 40 PCS", category: "beverages", categoryTitle: "عصائر ومشروبات", unit: "330 ML", storage: "جاف", shelfLifeMonths: 12 },

  // Powders & Sugar
  { id: "p_84", name: "HOT CHOCOLATE POWDER (6x1KG) CTN 6 PKT 1 KG", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "1 KG", storage: "جاف ومحكم الغلق", shelfLifeMonths: 18 },
  { id: "p_85", name: "MATCHA POWDER JUST CHILL (1KGX12 PCS) PKT 1 KG", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "1 KG", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_86", name: "POWDER.CHOCOLATE HOT POWDER BAG 03 LBS PKT 1.36 KG", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "1.36 KG", storage: "جاف ومحكم الغلق", shelfLifeMonths: 18 },
  { id: "p_87", name: "POWDER.FRAPPE-CHEESECAKE 1 KG PKT 1 KG", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "1 KG", storage: "جاف", shelfLifeMonths: 18 },
  { id: "p_88", name: "WHITE SUGAR (CTN x 14 PKT X 725 GRM) CTN 14 PKT 0.725 KG", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "0.725 KG", storage: "جاف", shelfLifeMonths: 36 },
  { id: "p_89", name: "SUGAR.BROWN SUGAR STICK (1X2000) CTN 2000 PCS", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "2000 PCS", storage: "جاف", shelfLifeMonths: 36 },
  { id: "p_90", name: "SUGAR.TROPICANA SLIM SUGAR (1X1200) CTN 12 PKT 100 PCS", category: "powders", categoryTitle: "بودرة وسكر ومحليات", unit: "1200 PCS", storage: "جاف", shelfLifeMonths: 36 },
  { id: "p_91", name: "NATA DE COCO / CAPPUCCINO FILLING 1KG PKT 1 KG", category: "powders", categoryTitle: "إضافات وحشوات", unit: "1 KG", storage: "جاف / مبرد بعد الفتح", shelfLifeMonths: 12 },
  { id: "p_92", name: "TOASTED COCONUT FLAKES (2x11.34 KG) CTN 2 PCS 11.34 KG", category: "powders", categoryTitle: "إضافات وحشوات", unit: "11.34 KG", storage: "جاف", shelfLifeMonths: 12 },

  // Snacks & Retail
  { id: "p_93", name: "COOKIE FLAVOR PROTEIN BAR 40 GRAM PKT 16 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "40 GM", storage: "جاف 18-22°C", shelfLifeMonths: 12 },
  { id: "p_94", name: "CRANBERRY MIXED NUT (50GM) 50 PCS PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "50 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_95", name: "ELIT CRISPY COATED PEANUTS BBQ 70G CTN 15 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "70 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_96", name: "ELIT CRISPY COATED PEANUTS COCKTAIL MIX 70G CTN 15 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "70 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_97", name: "ELIT CRISPY COATED PEANUTS PIZZA 70G CTN 15 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "70 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_98", name: "ELIT MARINATED PEANUT CHEDDAR 70G CTN 17 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "70 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_99", name: "FLAMIN CRUNCHIES (40GM) 50 PCS PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "40 GM", storage: "جاف", shelfLifeMonths: 9 },
  { id: "p_100", name: "MERCHANDISE.CARAMEL NUT 6X12X50G PKT 12 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "50 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_101", name: "MERCHANDISE.DOUBLE DARK CHOC NUT 6X12X50G PKT 12 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "50 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_102", name: "MINT TIN PKT 50 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "50 PCS", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_103", name: "SALTED PISTACHIO 50GM CTN 50 PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "50 GM", storage: "جاف", shelfLifeMonths: 12 },
  { id: "p_104", name: "SOUR CREAM AND ONION CRISPS 40GM 50PCS CTN PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "40 GM", storage: "جاف", shelfLifeMonths: 9 },
  { id: "p_105", name: "CHEESECAKE DRAGEES 40G PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "40 GM", storage: "جاف وبارد", shelfLifeMonths: 12 },
  { id: "p_106", name: "CHOCOLATE COFFEE SQUARES 35G PCS", category: "snacks", categoryTitle: "سناكات ومكسرات", unit: "35 GM", storage: "جاف وبارد", shelfLifeMonths: 12 },

  // Chemicals & Cleaners
  { id: "p_107", name: "CHEMICALS.CLEANER DETERGENT FOR COFFEE MACHINES 1LTR PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "1 LTR", storage: "مكان آمن للمواد الكيميائية", shelfLifeMonths: 24 },
  { id: "p_108", name: "CHEMICALS.CLEANER TABLET (12PACKX100PCS) CTN 12 PKT 100 PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "100 PCS", storage: "جاف ومحكم", shelfLifeMonths: 24 },
  { id: "p_109", name: "CHEMICALS.CLEANER TABLET CLEANER(BOX X 150PCS) PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "150 PCS", storage: "جاف ومحكم", shelfLifeMonths: 24 },
  { id: "p_110", name: "CHEMICALS.ESPRESSO MACHINE CLEANER 1KG PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "1 KG", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_111", name: "CHEMICALS.HAND SANITIZING GEL BOTTLE PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "1 BTL", storage: "جاف بعيد عن الحرارة", shelfLifeMonths: 24 },
  { id: "p_112", name: "CHEMICALS.HAYNES LUBRI FILM PLUS 113G PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "113 GM", storage: "جاف", shelfLifeMonths: 36 },
  { id: "p_113", name: "CHEMICALS.KAY QSR AMH HAND WASH 4 GALLON PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "4 GAL", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_114", name: "CHEMICALS.NAPHCARE-HAND SOAP 1 LTR PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_115", name: "CHEMICALS.SOFA CARE H41 ANTI-BACTERIAL HAND SOAP PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_116", name: "CHEMICALS.TEVO MINI TABLETS CTN 12 PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "12 PCS", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_117", name: "DISPOSABLES.DISTILLED WATER 1 LTR CTN 15 PCS", category: "chemicals", categoryTitle: "منظفات ومستهلكات", unit: "1 LTR", storage: "جاف", shelfLifeMonths: 36 },
  { id: "p_118", name: "ECOLAB CHEMICALS.KAY CHLORINE TEST STRIPS PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "1 BOX", storage: "جاف ومحكم", shelfLifeMonths: 24 },
  { id: "p_119", name: "ECOLAB CHEMICALS.KAY MULTI PURPOSE 1 BOX (168 SACHETS) CTN 168 PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "168 PCS", storage: "جاف", shelfLifeMonths: 24 },
  { id: "p_120", name: "ECOLAB KAY 5 SANITIZER TABLET 1 BOX (240 TABLETS) CTN 240 PCS", category: "chemicals", categoryTitle: "منظفات ومعقمات", unit: "240 TBL", storage: "جاف", shelfLifeMonths: 24 }
];

const DEFAULT_STORES = [
  { id: "str_1", name: "فرع الرياض - العليا", code: "RUH-01", city: "الرياض", address: "طريق الملك فهد" },
  { id: "str_2", name: "فرع الرياض - النخيل", code: "RUH-02", city: "الرياض", address: "النخيل مول" },
  { id: "str_3", name: "فرع جدة - الكورنيش", code: "JED-01", city: "جدة", address: "طريق الكورنيش" },
  { id: "str_4", name: "فرع الخبر - الراشد", code: "KHB-01", city: "الخبر", address: "مجمع الراشد" },
  { id: "str_5", name: "فرع مكة - العزيزية", code: "MAK-01", city: "مكة المكرمة", address: "طريق العزيزية" }
];

// Initial demo batches
const DEFAULT_BATCHES = [
  { id: "b_1", productId: "p_54", productName: "MILK.FULL FAT MILK 01 LTR CTN 12 PCS 1 LTR", category: "ألبان وحليب وبدائل", storeId: "str_1", batchNumber: "MK-2026-90", quantity: 24, unit: "1 LTR", prodDate: "2026-06-01", expiryDate: "2026-11-20" },
  { id: "p_2", productId: "p_41", productName: "COFFEE.DD COFFEE BEANS BAG 5 LBS CTN 6 PKT 2.27 KG", category: "قهوة وكبسولات", storeId: "str_1", batchNumber: "CF-8821", quantity: 18, unit: "2.27 KG", prodDate: "2026-02-15", expiryDate: "2027-02-15" },
  { id: "b_3", productId: "p_68", productName: "SANDWICH.LIQUID WHOLE EGG CHILLED PAST 1KG KG", category: "مخبوزات وساندوتشات", storeId: "str_2", batchNumber: "EG-102", quantity: 10, unit: "1 KG", prodDate: "2026-10-25", expiryDate: "2026-11-12" },
  { id: "b_4", productId: "p_1", productName: "BLUE BAY SYRUP (6 X1 LTR) PCS 1 LTR", category: "صوصات وسيروب", storeId: "str_3", batchNumber: "BB-501", quantity: 12, unit: "1 LTR", prodDate: "2025-12-01", expiryDate: "2027-06-01" },
  { id: "b_5", productId: "p_64", productName: "HONEY GRANULA YOGHURT 1X36X170G PCS", category: "ألبان وحليب وبدائل", storeId: "str_1", batchNumber: "YG-003", quantity: 36, unit: "170 GM", prodDate: "2026-10-10", expiryDate: "2026-11-05" }
];

createApp({
  setup() {
    const activeTab = ref('dashboard');
    const selectedStore = ref('ALL');
    const searchQuery = ref('');
    const batchFilterStatus = ref('ALL');
    const productFilterCategory = ref('ALL');

    const tabTitles = {
      dashboard: 'لوحة مؤشرات الصلاحية والإنذارات المبكرة',
      batches: 'سجل دفعات وتواريخ انتهاء المواد',
      products: 'دليل منتجات ومواصفات الصلاحية (120 صنف)',
      stores: 'شبكة فروع ومتاجر المجموعة'
    };

    const productCategories = [
      { name: "coffee", title: "القهوة وحبوب الإسبريسو", icon: "☕", storage: "مكان جاف وبارد 18-22°C" },
      { name: "syrups", title: "الصوصات والسيروب والبيوريه", icon: "🍯", storage: "جاف / مبرد بعد الفتح" },
      { name: "dairy", title: "الألبان والحليب والأجبان", icon: "🥛", storage: "مبرد 1-4°C / UHT" },
      { name: "bakery", title: "المخبوزات والبيض والساندوتشات", icon: "🥯", storage: "مجمد -18°C أو مبرد 1-4°C" },
      { name: "beverages", title: "العصائر والمياه والمشروبات", icon: "🧃", storage: "جاف / مبرد" },
      { name: "powders", title: "البودرة والسكر والإضافات", icon: "🧂", storage: "مكان جاف ومحكم الغلق" },
      { name: "snacks", title: "السناكات والمكسرات والبروتين", icon: "🥜", storage: "جاف ومعتدل" },
      { name: "chemicals", title: "المنظفات ومواد تطهير إيكولاب", icon: "🧴", storage: "مستودع الكيماويات المعتمد" }
    ];

    // Local Storage Loader
    const loadSavedData = () => {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error("Storage load error:", e);
      }
      return null;
    };

    const saved = loadSavedData();
    const stores = ref(saved?.stores || DEFAULT_STORES);
    const batches = ref(saved?.batches || DEFAULT_BATCHES);
    const products = ref(DUNKIN_PRODUCTS);

    const toast = ref({ show: false, message: '' });
    const showToast = (message) => {
      toast.value = { show: true, message };
      setTimeout(() => { toast.value.show = false; }, 3500);
    };

    const saveState = () => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          stores: stores.value,
          batches: batches.value
        }));
      } catch (e) {
        console.error("Storage save error:", e);
      }
    };

    // Date & Expiry Utilities
    const getDaysRemaining = (expiryDateStr) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const exp = new Date(expiryDateStr);
      exp.setHours(0, 0, 0, 0);
      const diffTime = exp.getTime() - today.getTime();
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    };

    const getDaysRemainingText = (expiryDateStr) => {
      const days = getDaysRemaining(expiryDateStr);
      if (days < 0) return `منتهي منذ ${Math.abs(days)} يوم`;
      if (days === 0) return 'ينتهي اليوم!';
      return `${days} يوم متبقي`;
    };

    const getDaysRemainingClass = (expiryDateStr) => {
      const days = getDaysRemaining(expiryDateStr);
      if (days <= 0) return 'text-red-600';
      if (days <= 30) return 'text-amber-500';
      return 'text-emerald-600';
    };

    const getStatusLabel = (expiryDateStr) => {
      const days = getDaysRemaining(expiryDateStr);
      if (days <= 0) return 'منتهي الصلاحية 🔴';
      if (days <= 30) return 'قارب على الانتهاء 🟡';
      return 'صالح وآمن 🟢';
    };

    const getStatusBadgeClass = (expiryDateStr) => {
      const days = getDaysRemaining(expiryDateStr);
      if (days <= 0) return 'bg-red-50 text-red-700 border-red-200';
      if (days <= 30) return 'bg-amber-50 text-amber-700 border-amber-200';
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    };

    const getStoreName = (storeId) => {
      if (storeId === 'ALL') return 'كافة الفروع';
      const s = stores.value.find(item => item.id === storeId);
      return s ? s.name : 'غير محدد';
    };

    const getProductsByCategory = (catName) => {
      return products.value.filter(p => p.category === catName);
    };

    const getBatchesByStore = (storeId) => {
      return batches.value.filter(b => b.storeId === storeId);
    };

    const getExpiringBatchesByStore = (storeId) => {
      return batches.value.filter(b => b.storeId === storeId && getDaysRemaining(b.expiryDate) <= 30);
    };

    // Filtered Batches
    const filteredBatches = computed(() => {
      let list = batches.value;

      if (selectedStore.value !== 'ALL') {
        list = list.filter(b => b.storeId === selectedStore.value);
      }

      if (batchFilterStatus.value === 'EXPIRED') {
        list = list.filter(b => getDaysRemaining(b.expiryDate) <= 0);
      } else if (batchFilterStatus.value === 'EXPIRING') {
        list = list.filter(b => {
          const d = getDaysRemaining(b.expiryDate);
          return d > 0 && d <= 30;
        });
      } else if (batchFilterStatus.value === 'VALID') {
        list = list.filter(b => getDaysRemaining(b.expiryDate) > 30);
      }

      if (searchQuery.value.trim()) {
        const q = searchQuery.value.toLowerCase();
        list = list.filter(b => 
          b.productName.toLowerCase().includes(q) || 
          b.batchNumber.toLowerCase().includes(q)
        );
      }

      return list.sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate));
    });

    // Counts
    const validBatchesCount = computed(() => {
      return filteredBatches.value.filter(b => getDaysRemaining(b.expiryDate) > 30).length;
    });

    const expiringSoonCount = computed(() => {
      return filteredBatches.value.filter(b => {
        const d = getDaysRemaining(b.expiryDate);
        return d > 0 && d <= 30;
      }).length;
    });

    const expiredCount = computed(() => {
      return filteredBatches.value.filter(b => getDaysRemaining(b.expiryDate) <= 0).length;
    });

    const expiringSoonBatches = computed(() => {
      return filteredBatches.value.filter(b => {
        const d = getDaysRemaining(b.expiryDate);
        return d > 0 && d <= 30;
      });
    });

    // Filtered Products
    const filteredProducts = computed(() => {
      let list = products.value;
      if (productFilterCategory.value !== 'ALL') {
        list = list.filter(p => p.category === productFilterCategory.value);
      }
      if (searchQuery.value.trim()) {
        const q = searchQuery.value.toLowerCase();
        list = list.filter(p => p.name.toLowerCase().includes(q));
      }
      return list;
    });

    // Batch Modal Logic
    const showBatchModal = ref(false);
    const batchForm = ref({
      id: null,
      productId: '',
      productName: '',
      category: '',
      storeId: '',
      batchNumber: '',
      quantity: 1,
      unit: '',
      prodDate: '',
      expiryDate: ''
    });

    const onProductSelectChange = () => {
      const prod = products.value.find(p => p.id === batchForm.value.productId);
      if (prod) {
        batchForm.value.productName = prod.name;
        batchForm.value.category = prod.categoryTitle;
        batchForm.value.unit = prod.unit;
        autoCalculateExpiry();
      }
    };

    const autoCalculateExpiry = () => {
      const prod = products.value.find(p => p.id === batchForm.value.productId);
      if (prod && batchForm.value.prodDate) {
        const pDate = new Date(batchForm.value.prodDate);
        pDate.setMonth(pDate.getMonth() + (prod.shelfLifeMonths || 12));
        batchForm.value.expiryDate = pDate.toISOString().split('T')[0];
      }
    };

    const openBatchModal = (batch = null) => {
      if (batch) {
        batchForm.value = JSON.parse(JSON.stringify(batch));
      } else {
        const todayStr = new Date().toISOString().split('T')[0];
        const nextBatchNo = 'B' + Math.floor(Math.random() * 9000 + 1000);
        batchForm.value = {
          id: null,
          productId: products.value[0]?.id || '',
          productName: products.value[0]?.name || '',
          category: products.value[0]?.categoryTitle || '',
          storeId: selectedStore.value === 'ALL' ? stores.value[0]?.id : selectedStore.value,
          batchNumber: nextBatchNo,
          quantity: 12,
          unit: products.value[0]?.unit || 'PCS',
          prodDate: todayStr,
          expiryDate: ''
        };
        autoCalculateExpiry();
      }
      showBatchModal.value = true;
    };

    const quickAddBatchFromProduct = (prod) => {
      openBatchModal();
      batchForm.value.productId = prod.id;
      onProductSelectChange();
    };

    const saveBatch = () => {
      if (batchForm.value.id) {
        const idx = batches.value.findIndex(b => b.id === batchForm.value.id);
        if (idx !== -1) {
          batches.value[idx] = { ...batchForm.value };
          showToast(`تم تحديث بيانات الدفعة (${batchForm.value.batchNumber})`);
        }
      } else {
        const newBatch = {
          ...batchForm.value,
          id: 'b_' + Date.now()
        };
        batches.value.unshift(newBatch);
        showToast(`تم تسجيل الدفعة الجديدة (${newBatch.batchNumber}) بنجاح`);
      }
      saveState();
      showBatchModal.value = false;
      refreshIcons();
    };

    const deleteBatch = (b) => {
      if (confirm(`هل أنت متأكد من حذف / إتلاف الدفعة (${b.batchNumber}) للصنف [${b.productName}]؟`)) {
        batches.value = batches.value.filter(item => item.id !== b.id);
        saveState();
        showToast(`تم حذف الدفعة (${b.batchNumber})`);
        refreshIcons();
      }
    };

    // Label printing preview
    const printingBatch = ref(null);
    const printBatchLabel = (b) => {
      printingBatch.value = b;
      refreshIcons();
    };

    // Quick navigation
    const filterByCategory = (catName) => {
      productFilterCategory.value = catName;
      activeTab.value = 'products';
    };

    const selectStoreAndGoToBatches = (storeId) => {
      selectedStore.value = storeId;
      activeTab.value = 'batches';
    };

    // Reset Data
    const resetToDefaultData = () => {
      if (confirm('هل ترغب في استعادة البيانات التجريبية الافتراضية؟')) {
        localStorage.removeItem(STORAGE_KEY);
        stores.value = [...DEFAULT_STORES];
        batches.value = [...DEFAULT_BATCHES];
        showToast('تمت استعادة البيانات الافتراضية بنجاح');
        refreshIcons();
      }
    };

    // Export Backup
    const exportData = () => {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({
        stores: stores.value,
        batches: batches.value,
        exportedAt: new Date().toISOString()
      }, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `dunkin_shelf_life_backup_${Date.now()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showToast('تم تصدير نسخة احتياطية بنجاح');
    };

    const refreshIcons = () => {
      nextTick(() => {
        if (window.lucide) window.lucide.createIcons();
      });
    };

    watch(activeTab, () => refreshIcons());
    onMounted(() => refreshIcons());

    return {
      activeTab,
      tabTitles,
      selectedStore,
      searchQuery,
      batchFilterStatus,
      productFilterCategory,
      productCategories,
      stores,
      products,
      batches,
      filteredBatches,
      filteredProducts,
      validBatchesCount,
      expiringSoonCount,
      expiredCount,
      expiringSoonBatches,
      showBatchModal,
      batchForm,
      printingBatch,
      toast,
      getDaysRemaining,
      getDaysRemainingText,
      getDaysRemainingClass,
      getStatusLabel,
      getStatusBadgeClass,
      getStoreName,
      getProductsByCategory,
      getBatchesByStore,
      getExpiringBatchesByStore,
      openBatchModal,
      quickAddBatchFromProduct,
      onProductSelectChange,
      autoCalculateExpiry,
      saveBatch,
      deleteBatch,
      printBatchLabel,
      filterByCategory,
      selectStoreAndGoToBatches,
      resetToDefaultData,
      exportData
    };
  }
}).mount('#app');
