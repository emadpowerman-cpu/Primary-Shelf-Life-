@echo off
chcp 65001 >nul
title Store Permissions Pro - Multi-Store RBAC
echo Launching Store Permissions Web App in your browser...
start "" "%~dp0index.html"
exit

